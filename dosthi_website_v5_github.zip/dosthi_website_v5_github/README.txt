Replace index.html in your GitHub repo with this file.
